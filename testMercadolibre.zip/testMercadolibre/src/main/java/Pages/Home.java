package Pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by f.pucciarelli on 7/7/2017.
 */
public class Home {
    public static final String PAGE_TITLE = "Mercado Libre Argentina";
    public static final String PAGE_URL = "http://www.mercadolibre.com.ar/";
    public static final String PRODUCT_SEARCH = "iphone";


    @FindBy(xpath = "//input[@type='text']")
    private static WebElement search_Box;

    @FindBy(xpath = ".//*[@id='searchResults']/li[1]/div/div[1]")
    private static WebElement primer_Resultado;

    @FindBy(xpath = "//button[contains(.,'Buscar')]")
    private static WebElement boton_Buscar;


    static WebDriver driver;

    public Home(WebDriver driver) {
        this.driver = driver;
        driver.manage().window().maximize();
    }

    //Verify page status
    public static void verifyPage(WebDriver driver, String url, String title) {
        Assert.assertEquals(driver.getTitle(), title);
        Assert.assertEquals(driver.getCurrentUrl(), url);
    }

    //Set search
    public static void setCompanySearch() {
        search_Box.clear();
        search_Box.sendKeys(PRODUCT_SEARCH);
        boton_Buscar.click();
        primer_Resultado.click();

    }
}
