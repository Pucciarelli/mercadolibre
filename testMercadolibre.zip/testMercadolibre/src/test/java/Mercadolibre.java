/**
 * Created by f.pucciarelli on 7/7/2017.
 */
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.*;
import Pages.Home;

public class Mercadolibre {
    public WebDriver driver;
    Home hPage;

    @BeforeClass(alwaysRun = true)
    public void setUp() {
        this.driver = new FirefoxDriver();
        hPage = PageFactory.initElements(driver, Home.class);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @BeforeMethod()
    public void upPage() {
        this.driver.get(hPage.PAGE_URL);
        hPage.verifyPage(driver,hPage.PAGE_URL,hPage.PAGE_TITLE);
    }

    @AfterClass(alwaysRun = true)
    public void tearDown() {
        this.driver.close();
    }

    @Test(groups = "p1")
    public void loadMainPage() {
        hPage.setCompanySearch();
    }
}
