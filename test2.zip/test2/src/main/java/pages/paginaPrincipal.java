package pages; /**
 * Created by f.pucciarelli on 7/7/2017.
 */
import Utils.Utils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

public class paginaPrincipal {
    public static final String PAGE_TITLE = "Users";
    public static final String PAGE_URL = "https://api.mercadolibre.com/users/1#json";
    public static final String NICKNAME_SEARCH = "nickname";
    public static final String COUNTRY_SEARCH = "country_id";


    @FindBy(css = ".collapsible")
    private static WebElement search_json;

    static WebDriver driver;

    public paginaPrincipal(WebDriver driver) {
        this.driver = driver;
        driver.manage().window().maximize();
        Utils.writeFile("Open json page--- DONE");
    }

    //Verify page status
    public static void verifyPage(WebDriver driver, String url, String title) {
        Assert.assertEquals(driver.getTitle(), title);
        Utils.writeFile("Page Title--- OK");
        Assert.assertEquals(driver.getCurrentUrl(), url);
        Utils.writeFile("URL--- OK");
    }

    //Set search
    public static void setExport() {
        //search_Box.clear();
        //search_json
        Utils.writeFile(search_json.getText());
        Utils.writeFile("Set Export Search OK: " + NICKNAME_SEARCH);
    }

}
