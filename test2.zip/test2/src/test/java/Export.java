/**
 * Created by f.pucciarelli on 7/7/2017.
 */
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.*;
import pages.paginaPrincipal;
import Utils.Utils;

public class Export {
    public WebDriver driver;
    paginaPrincipal gPage;

    @BeforeClass(alwaysRun = true)
    public void setUp() {
        Utils.openFile("Report");
        this.driver = new FirefoxDriver();
        gPage = PageFactory.initElements(driver, paginaPrincipal.class);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @BeforeMethod()
    public void upPage() {
        this.driver.get(paginaPrincipal.PAGE_URL);
        paginaPrincipal.verifyPage(driver,paginaPrincipal.PAGE_URL,paginaPrincipal.PAGE_TITLE);
    }

    @AfterClass(alwaysRun = true)
    public void tearDown() {
        this.driver.close();
        Utils.CloseFile("Report");
    }

    @Test(groups = "p1")
    public void loadMainPage() {
        paginaPrincipal.setExport();

    }

}
